
public class Solution25 {
	public static void main(String[] args) {
		char ch='E';
		for(int i=1;i<=3;i++) {
			for(int j=1;j<=4;j++) {
				System.out.print(ch+" ");
				ch++;
			}
			System.out.println();
		}
	}
}
